<?php
include("connection.php");

// Start the session to get the user ID
session_start();
$user_id = $_SESSION['user_id']; // Make sure you have this session variable set

// Check if the receipt ID is provided in the URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "No invoice selected.";
    exit;
}

$receipt_id = (int)$_GET['id'];

// Get the user's name
$user_sql = "SELECT firstname, lastname FROM user WHERE id = ?";
$user_stmt = mysqli_prepare($conn, $user_sql);
mysqli_stmt_bind_param($user_stmt, "i", $user_id);
mysqli_stmt_execute($user_stmt);
$user_result = mysqli_stmt_get_result($user_stmt);
$user = mysqli_fetch_assoc($user_result);

// Get the specific receipt information for the user
$sql = "SELECT * FROM receipts WHERE user_id = ? AND receipt_id = ?";
$stmtReceipt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmtReceipt, "ii", $user_id, $receipt_id);
mysqli_stmt_execute($stmtReceipt);
$resultReceipt = mysqli_stmt_get_result($stmtReceipt);
$receipt = mysqli_fetch_assoc($resultReceipt);

if ($receipt) {
    $invoice_number = $receipt['invoice_number'];
    $total_price = $receipt['total_price'];
    $delivery = $receipt['delivery'];
    $created_at = $receipt['created_at'];
    
    // Get the receipt items with model names
    $items_sql = "
        SELECT w.model_name, ri.quantity, ri.price 
        FROM receipt_items ri 
        JOIN watch w ON ri.product_id = w.id 
        WHERE ri.receipt_id = ?";
    $stmtItems = mysqli_prepare($conn, $items_sql);
    mysqli_stmt_bind_param($stmtItems, "i", $receipt_id);
    mysqli_stmt_execute($stmtItems);
    $items_result = mysqli_stmt_get_result($stmtItems);
} else {
    echo "No receipt found.";
    exit;
}

// HTML for the receipt
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Receipt</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="float-end">Invoice #<?= htmlspecialchars($invoice_number) ?></h4>
                    <div class="mb-4">
                        <h2 class="mb-1 text-muted">WatchHub</h2>
                    </div>
                    <div class="text-muted">
                        <p class="mb-1">Name: <?= htmlspecialchars($user['firstname'] . ' ' . $user['lastname']) ?></p>
                        <p class="mb-1">Delivery Address: <?= htmlspecialchars($delivery) ?></p>
                        <p><?= htmlspecialchars($created_at) ?></p>
                    </div>
                    <hr class="my-4">

                    <div class="py-2">
                        <h5>Order Summary</h5>
                        <div class="table-responsive">
                            <table class="table align-middle table-nowrap table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Item</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th class="text-end">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $total_amount = 0;
                                    $item_number = 1;

                                    while ($item = mysqli_fetch_assoc($items_result)) {
                                        $total_item_price = $item['price'] * $item['quantity']; // Calculate total price per item
                                        $total_amount += $total_item_price; // Sum up the total amount
                                        ?>
                                        <tr>
                                            <th scope="row"><?= $item_number++ ?></th>
                                            <td><?= htmlspecialchars($item['model_name']) ?></td> <!-- Display model name -->
                                            <td>$ <?= number_format($item['price'], 2) ?></td>
                                            <td><?= htmlspecialchars($item['quantity']) ?></td>
                                            <td class="text-end">$ <?= number_format($total_item_price, 2) ?></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                    <tr>
                                        <th scope="row" colspan="4" class="text-end">Total</th>
                                        <td class="text-end">$ <?= number_format($total_price, 2) ?></td> <!-- Ensure this matches the stored total price -->
                                    </tr>
                                    <tr>
                                        <th scope="row" colspan="4" class="text-end">Calculated Total</th>
                                        <td class="text-end">$ <?= number_format($total_amount, 2) ?></td> <!-- Show calculated total -->
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-print-none mt-4">
                            <div class="float-end">
                                <a href="javascript:window.print()" class="btn btn-success me-1">Print</a>
                                <a href="index.php" class="btn btn-primary">Home</a> <!-- Home button -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- end col -->
    </div>
</div>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
