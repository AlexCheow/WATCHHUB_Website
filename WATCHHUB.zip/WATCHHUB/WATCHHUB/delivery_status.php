<?php
include("connection.php");

// Get receipt_id from URL or session
$receipt_id = $_GET['receipt_id'];

// Fetch receipt, delivery status, and total price
$receipt_query = "SELECT r.invoice_number, r.created_at, r.total_price, r.delivery, d.status
                  FROM receipts r
                  JOIN delivery_status d ON r.receipt_id = d.receipt_id
                  WHERE r.receipt_id = $receipt_id";
$receipt_result = $conn->query($receipt_query);
$receipt = $receipt_result->fetch_assoc();

// Fetch purchased items
$items_query = "SELECT p.model_name, ri.quantity, ri.price
                FROM receipt_items ri
                JOIN watch p ON ri.product_id = p.id
                WHERE ri.receipt_id = $receipt_id";
$items = $conn->query($items_query);

// Define possible statuses
$statuses = ["Order Processed", "Order Shipped", "En Route", "Order Arrived"];
$current_status_index = array_search($receipt['status'], $statuses);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delivery Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .status-container {
            background-color: #e0e7ff;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            max-width: 700px;
            margin: auto;
        }
        .status-tracker {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
        .status-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100px;
        }
        .status-circle {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background-color: #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 12px;
            margin-bottom: 8px;
        }
        .status-circle.active {
            background-color: #5a67d8;
        }
        .status-line {
            height: 4px;
            background-color: #5a67d8;
            flex-grow: 1;
            margin: 0 8px;
        }
        .status-line.inactive {
            background-color: #ccc;
        }
    </style>
</head>
<body>

<div class="container my-5">
    <div class="status-container">
        <h5>INVOICE #<?php echo htmlspecialchars($receipt['invoice_number']); ?></h5>
        <p>Expected Arrival: <?php echo date('d/m/Y', strtotime('+7 days', strtotime($receipt['created_at']))); ?></p>

        <!-- Status Tracker -->
        <div class="status-tracker">
            <?php foreach ($statuses as $index => $status): ?>
                <div class="status-step">
                    <div class="status-circle <?php echo $index <= $current_status_index ? 'active' : ''; ?>">
                        <?php echo $index + 1; ?>
                    </div>
                    <p><?php echo $status; ?></p>
                    <?php if ($index < count($statuses) - 1): ?>
                        <div class="status-line <?php echo $index < $current_status_index ? '' : 'inactive'; ?>"></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Total Price and Address -->
        <div class="mt-4">
            <p><strong>Delivery Address:</strong> <?php echo htmlspecialchars($receipt['delivery']); ?></p>
        </div>
    </div>

    <!-- Purchased Items -->
    <h4 class="mt-5">Items Purchased</h4>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price (RM)</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['model_name']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td><?php echo number_format($item['price'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <p><strong>Total Price:</strong> RM <?php echo number_format($receipt['total_price'], 2); ?></p>
    
    <!-- Back to Orders Button -->
    <a href="orders.php" class="btn btn-primary mt-3">Back to Orders</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
