<?php
session_start();
include("connection.php");

// Check if all required session data is available
if (!isset($_SESSION['user_id'])) {
    echo "Error: User not logged in.";
    exit();
}

if (!isset($_SESSION['cart_items']) || empty(unserialize($_SESSION['cart_items']))) {
    echo "Error: Cart is empty. Please add items to the cart.";
    exit();
}

if (!isset($_SESSION['selected_address'])) {
    echo "Error: Address not selected. Please choose a delivery address.";
    exit();
}

if (!isset($_SESSION['selected_card'])) {
    echo "Error: Payment card not selected. Please choose a payment card.";
    exit();
}

// Retrieve session data
$user_id = $_SESSION['user_id'];
$cart_items = unserialize($_SESSION['cart_items']);
$selected_address = $_SESSION['selected_address'];
$selected_card = $_SESSION['selected_card'];

// Calculate total price for the order
$total_price = 0;
foreach ($cart_items as $item) {
    $total_price += $item['product_price'] * $item['quantity'];
}

// Generate a unique invoice number
$invoice_number = uniqid('INV-', true);

// Insert into `receipts` table
$receipt_query = "INSERT INTO receipts (user_id, invoice_number, total_price, delivery, created_at) VALUES (?, ?, ?, ?, NOW())";
$stmt_receipt = mysqli_prepare($conn, $receipt_query);
$delivery = 'Standard';
mysqli_stmt_bind_param($stmt_receipt, 'isss', $user_id, $invoice_number, $total_price, $delivery);
mysqli_stmt_execute($stmt_receipt);
$receipt_id = mysqli_insert_id($conn);
mysqli_stmt_close($stmt_receipt);

// Insert each cart item into `receipt_items` table
$item_query = "INSERT INTO receipt_items (receipt_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
$stmt_item = mysqli_prepare($conn, $item_query);

foreach ($cart_items as $item) {
    $product_id = $item['product_id'];
    $quantity = $item['quantity'];
    $price = $item['product_price'];
    mysqli_stmt_bind_param($stmt_item, 'iiid', $receipt_id, $product_id, $quantity, $price);
    mysqli_stmt_execute($stmt_item);
}
mysqli_stmt_close($stmt_item);

// Insert into `delivery_status` table with initial status 'Pending'
$status_query = "INSERT INTO delivery_status (receipt_id, status) VALUES (?, 'Pending')";
$stmt_status = mysqli_prepare($conn, $status_query);
mysqli_stmt_bind_param($stmt_status, 'i', $receipt_id);
mysqli_stmt_execute($stmt_status);
mysqli_stmt_close($stmt_status);

// Clear the cart items from session
unset($_SESSION['cart_items']);

// Set success message and store receipt ID in session
$_SESSION['receipt_id'] = $receipt_id;
$_SESSION['payment_success'] = "Payment processed successfully!";

// Redirect to receipt page
header("Location: receipt.php");
exit();
?>
