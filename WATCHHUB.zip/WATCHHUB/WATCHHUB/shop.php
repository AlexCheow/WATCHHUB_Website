<?php
include("connection.php");
session_start();

// Fetch all brands for the filter
$brand_query = "SELECT id, name FROM brand";
$brand_result = $conn->query($brand_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>PRODUCT</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
</head>

<body>
    <!-- Start Top Nav -->
    <?php include("nav.php"); ?>

    <!-- Start Content Display -->
    <div class="container py-5">
        <div class="row">
            <!-- Filter Sidebar -->
            <div class="col-lg-3">
                <h1 class="h2 pb-4">Categories</h1>
                <form method="GET" action="shop.php">
                    <ul class="list-unstyled templatemo-accordion">
                        <!-- Gender Filter -->
                        <li class="pb-3">
                            <a class="collapsed d-flex justify-content-between h3 text-decoration-none" data-bs-toggle="collapse" href="#genderFilter" aria-expanded="false">
                                Gender
                                <i class="fa fa-fw fa-chevron-circle-down mt-1"></i>
                            </a>
                            <ul class="collapse list-unstyled pl-3" id="genderFilter">
                                <li><input type="checkbox" name="gender[]" value="Men"> Men</li>
                                <li><input type="checkbox" name="gender[]" value="Women"> Women</li>
                            </ul>
                        </li>

                        <!-- Case Material Filter -->
                        <li class="pb-3">
                            <a class="collapsed d-flex justify-content-between h3 text-decoration-none" data-bs-toggle="collapse" href="#caseMaterialFilter" aria-expanded="false">
                                Case Material
                                <i class="fa fa-fw fa-chevron-circle-down mt-1"></i>
                            </a>
                            <ul class="collapse list-unstyled pl-3" id="caseMaterialFilter">
                                <li><input type="checkbox" name="case_material[]" value="Steel"> Steel</li>
                                <li><input type="checkbox" name="case_material[]" value="Plastic"> Plastic</li>
                                <li><input type="checkbox" name="case_material[]" value="Leather"> Leather</li>
                            </ul>
                        </li>

                        <!-- Movement Type Filter -->
                        <li class="pb-3">
                            <a class="collapsed d-flex justify-content-between h3 text-decoration-none" data-bs-toggle="collapse" href="#movementTypeFilter" aria-expanded="false">
                                Movement Type
                                <i class="fa fa-fw fa-chevron-circle-down mt-1"></i>
                            </a>
                            <ul class="collapse list-unstyled pl-3" id="movementTypeFilter">
                                <li><input type="checkbox" name="movement_type[]" value="Automatic"> Automatic</li>
                                <li><input type="checkbox" name="movement_type[]" value="Quartz"> Quartz</li>
                            </ul>
                        </li>

                        <!-- Brand Filter -->
                        <li class="pb-3">
                            <a class="collapsed d-flex justify-content-between h3 text-decoration-none" data-bs-toggle="collapse" href="#brandFilter" aria-expanded="false">
                                Brand
                                <i class="fa fa-fw fa-chevron-circle-down mt-1"></i>
                            </a>
                            <ul class="collapse list-unstyled pl-3" id="brandFilter">
                                <?php while ($brand = $brand_result->fetch_assoc()): ?>
                                    <li><input type="checkbox" name="brand[]" value="<?php echo $brand['id']; ?>"> <?php echo $brand['name']; ?></li>
                                <?php endwhile; ?>
                            </ul>
                        </li>
                    </ul>
                    <button type="submit" class="btn btn-success mt-3">Apply Filters</button>
                </form>
            </div>

            <!-- Product Display Section -->
            <div class="col-lg-9">
                <div class="row">
                    <!-- Search Bar -->
                    <div class="col-md-12 pb-4">
                        <form method="GET" action="shop.php" class="d-flex">
                            <input type="text" name="search" class="form-control" placeholder="Search for products" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                            <button type="submit" class="btn btn-success ms-2">Search</button>
                        </form>
                    </div>

                    <!-- Sorting Options -->
                    <div class="col-md-6 pb-4">
                        <form method="GET" action="shop.php">
                            <div class="d-flex">
                                <select name="sort" class="form-control" onchange="this.form.submit()">
                                    <option value="">Sort By</option>
                                    <option value="name_asc">A to Z</option>
                                    <option value="price_asc">Price: Low to High</option>
                                    <option value="price_desc">Price: High to Low</option>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Product Display (Dynamic Loop) -->
                <div class="row">
                    <?php
                    // Start building the SQL query
                    $product_query = "SELECT * FROM watch WHERE status = 'active'";
                    $conditions = [];

                    // Apply filters
                    if (!empty($_GET['gender'])) {
                        $genders = implode("','", $_GET['gender']);
                        $conditions[] = "gender IN ('$genders')";
                    }
                    if (!empty($_GET['case_material'])) {
                        $materials = implode("','", $_GET['case_material']);
                        $conditions[] = "case_material IN ('$materials')";
                    }
                    if (!empty($_GET['movement_type'])) {
                        $movements = implode("','", $_GET['movement_type']);
                        $conditions[] = "movement_type IN ('$movements')";
                    }
                    if (!empty($_GET['brand'])) {
                        $brands = implode(",", $_GET['brand']);
                        $conditions[] = "brand_id IN ($brands)";
                    }

                    // Apply search term
                    if (!empty($_GET['search'])) {
                        $search = $conn->real_escape_string($_GET['search']);
                        $conditions[] = "(model_name LIKE '%$search%')";
                    }

                    // Append conditions to the SQL query
                    if (!empty($conditions)) {
                        $product_query .= " AND " . implode(" AND ", $conditions);
                    }

                    // Handle sorting
                    if (isset($_GET['sort'])) {
                        $sort = $_GET['sort'];
                        if ($sort == "name_asc") {
                            $product_query .= " ORDER BY model_name ASC";
                        } elseif ($sort == "price_asc") {
                            $product_query .= " ORDER BY price ASC";
                        } elseif ($sort == "price_desc") {
                            $product_query .= " ORDER BY price DESC";
                        }
                    }

                    // Execute the query
                    $result = $conn->query($product_query);

                    // Loop through each product and display
                    while ($product = $result->fetch_assoc()) {
                        echo '
                        <div class="col-md-4">
                            <div class="card mb-4 product-wap rounded-0">
                                <div class="card rounded-0">
                                    <img src="data:image/jpeg;base64,'.base64_encode($product['image_url']).'" class="card-img-top" alt="Product Image">
                                    <div class="card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center">
                                        <ul class="list-unstyled">
                                            <li><a class="btn btn-success text-white mt-2" href="shop-single.php?id='.$product['id'].'"><i class="far fa-eye"></i></a></li>
                                            <li><a class="btn btn-success text-white mt-2" href="add_to_cart.php?id='.$product['id'].'"><i class="fas fa-cart-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <a href="shop-single.php?id='.$product['id'].'" class="h3 text-decoration-none">'.$product['model_name'].'</a>
                                    <p class="text-center mb-0">$'.$product['price'].'</p>
                                </div>
                            </div>
                        </div>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include("footer.php"); ?>

    <!-- Scripts -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
