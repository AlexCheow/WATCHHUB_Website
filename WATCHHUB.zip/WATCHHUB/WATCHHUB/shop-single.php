<!DOCTYPE html>
<html lang="en">

<head>
    <title>Product Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

    <style>
        /* Tabs Styling */
        .nav-tabs .nav-link {
            color: #555;
            font-weight: 600;
        }

        .nav-tabs .nav-link.active {
            color: #000;
            border-color: #ddd;
            border-bottom: 3px solid #333;
        }

        /* Padding for content */
        .tab-content {
            padding: 15px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-top: none;
            border-radius: 0 0 8px 8px;
        }
    </style>
</head>

<body>

    <!-- Start Top Nav -->
    <?php include("nav.php"); ?>
    <!-- Close Header -->

    <!-- Product Details Section -->
    <div class="container py-5">
        <div class="row">
            <!-- Product Image -->
            <div class="col-lg-5">
                <div class="card mb-3">
                    <?php
                    // Fetch the watch details based on the ID passed via GET
                    include("connection.php"); // Database connection
                    
                    $product_id = $_GET['id']; // Get the product ID from URL
                    $product_query = "SELECT * FROM watch WHERE id = $product_id";
                    $result = $conn->query($product_query);
                    $product = $result->fetch_assoc();
                    
                    $image_query = "SELECT image_url FROM watch WHERE id = " . $product['id'];
                    $image_result = $conn->query($image_query);
                    $image = $image_result->fetch_assoc();
                    ?>
                    <img src="data:image/jpeg;base64,<?php echo base64_encode($image['image_url']); ?>" class="card-img-top" alt="Product Image">
                </div>
            </div>

            <!-- Product Info -->
            <div class="col-lg-7">
                <h1 class="h2"><?php echo $product['model_name']; ?></h1>
                <p class="h3 py-2">$<?php echo number_format($product['price'], 2); ?></p>
                
                <!-- Product Specifications -->
                <ul class="list-unstyled">
                    <li><strong>Gender:</strong> <?php echo $product['gender']; ?></li>
                    <li><strong>Case Material:</strong> <?php echo $product['case_material']; ?></li>
                    <li><strong>Movement Type:</strong> <?php echo $product['movement_type']; ?></li>
                    <li><strong>Strap Material:</strong> <?php echo $product['strap_material']; ?></li>
                </ul>

        		<p><strong>Stock Left:</strong> <?php echo $product['quantity']; ?></p>

                <!-- Add to Cart Button -->
                <a href="cart.php?action=add&id=<?php echo $product['id']; ?>" class="btn btn-success">Add to Cart</a>
            </div>
        </div>

        <!-- More Information Section with Tabs -->
        <div class="mt-5">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="details-tab" data-bs-toggle="tab" data-bs-target="#details" type="button" role="tab" aria-controls="details" aria-selected="true">Description</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="security-tab" data-bs-toggle="tab" data-bs-target="#security" type="button" role="tab" aria-controls="security" aria-selected="false">Specification</button>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="details" role="tabpanel" aria-labelledby="details-tab">
                    <!-- Details content here -->
                    <p><?php echo nl2br($product['description']); ?></p>
                </div>
                <div class="tab-pane fade" id="security" role="tabpanel" aria-labelledby="security-tab">
                    <!-- Security content here -->
                    <p><?php echo nl2br($product['specification']); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Start FOOTER -->
    <?php include("footer.php"); ?>
    <!-- Close FOOTER -->

    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->

</body>

</html>
