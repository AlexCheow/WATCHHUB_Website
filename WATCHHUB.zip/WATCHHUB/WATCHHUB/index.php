<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit;
}

// Retrieve user information from the session
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$user_mail = $_SESSION['user_mail'];


?>
<html lang="en">

<head>
    <title>WATCHHUB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

</head>

<body>
    
<!-- Start Top Nav -->

    <?php include("nav.php"); ?>

    <!-- Modal -->
    <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="get" class="modal-content modal-body border-0 p-0">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="inputModalSearch" name="q" placeholder="Search ...">
                    <button type="submit" class="input-group-text bg-success text-light">
                        <i class="fa fa-fw fa-search text-white"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>



    <!-- Start Banner Hero -->
    <div id="template-mo-zay-hero-carousel" class="carousel slide" data-bs-ride="carousel">
        <ol class="carousel-indicators">
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="1"></li>
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="./assets/img/banner_img_01.png" alt="">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left align-self-center">
                                <h1 class="h1 text-success"><b>LONGINES</b> Conquest</h1>
                                <h3 class="h2">Elegance Is An Attitude</h3>
                                <p>
                                    Without sacrificing elegance, the Conquest line perpetuates the spirit of conquest of all those who have dared to go further than others in their quest for new horizons. The same spirit has been behind the models in the Conquest collection since 1954. Each watch contains a subtle fusion of performance and elegance, including the most demanding technical features.
                                    
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="./assets/img/banner_img_02.png" alt="">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left">
								<h1 class="h1 text-success"><b>OMEGA</b> Speedmaster Moonwatch Professional</h1>
                                <h3 class="h2">Exact Time For Life</h3>
                                <p>
                                    The Speedmaster Moonwatch is one of the world’s most iconic timepieces. Having been a part of all six moon landings, the legendary chronograph is an impressive representation of the brand’s adventurous pioneering spirit.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="./assets/img/banner_img_03.png" alt="">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left">
                                <h1 class="h1 text-success"><b>BELL & ROSE</b> BR S Black Diamond Eagle Diamonds</h1>
                                <h3 class="h2">The Essential Must Not Compromise The Superfluous </h3>
                                <p>
                                    This Bell & Ross BR S with Reference BRS-EBL-CE/SCA has a 39mm Ceramic Case. It features a Black Diamond Dial on a Black Calfskin Leather Strap.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev text-decoration-none w-auto ps-3" href="#template-mo-zay-hero-carousel" role="button" data-bs-slide="prev">
            <i class="fas fa-chevron-left"></i>
        </a>
        <a class="carousel-control-next text-decoration-none w-auto pe-3" href="#template-mo-zay-hero-carousel" role="button" data-bs-slide="next">
            <i class="fas fa-chevron-right"></i>
        </a>
    </div>
    <!-- End Banner Hero -->


	



<!-- Start Top Selling Products -->
<section class="container py-5">
    <div class="row text-center pt-3">
        <div class="col-lg-6 m-auto">
            <h1 class="h1">Top-Selling Products</h1>
            <p>
                Discover our best-selling products loved by customers around the globe.
            </p>
        </div>
    </div>
    <div class="row">
        <?php
        include("connection.php");  // Include the database connection

        // Fetch top-selling products
        $salesQuery = "
            SELECT 
                mo.id AS product_id,  
                mo.model_name AS model_name,
                mo.price AS price,
                SUM(ri.quantity) AS total_quantity_sold,
                mo.image_url AS image_url  
            FROM 
                receipt_items AS ri
            JOIN 
                watch AS mo ON ri.product_id = mo.id
            GROUP BY 
                ri.product_id
            ORDER BY 
                total_quantity_sold DESC
            LIMIT 3  
        ";

        $result = mysqli_query($conn, $salesQuery);  

        // Check if there are results
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="col-12 col-md-4 p-5 mt-3">';
                echo '<div class="card h-100">';
                echo '<a href="shop-single.php?id=' . $row['product_id'] . '">';  // Link to product detail page
                
                // Check if image_url is valid and display the image
                if (!empty($row['image_url'])) {
                    echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image_url']) . '" class="card-img-top" alt="' . htmlspecialchars($row['model_name']) . '">';
                } else {
                    echo '<img src="./assets/img/default_image.jpg" class="card-img-top" alt="Default Image">'; // Default image if none is available
                }
                
                echo '</a>';
                echo '<div class="card-body">';
                echo '<h2 class="h5 text-center mt-3 mb-3">' . htmlspecialchars($row['model_name']) . '</h2>';
                echo '<ul class="list-unstyled d-flex justify-content-between">';
                echo '<li class="text-muted text-right">$' . number_format($row['price'], 2) . '</li>';
                echo '</ul>';
                echo '<p>Total Sold: ' . $row['total_quantity_sold'] . ' /Month</p>';
                
                // Add Go to Shop button with dynamic link
                echo '<div class="text-center mt-3">';
                echo '<a href="shop-single.php?id=' . $row['product_id'] . '" class="btn btn-success">Go to Shop</a>';  // Link to product detail page
                echo '</div>';
                
                echo '</div>';  // Close card-body
                echo '</div>';  // Close card
                echo '</div>';  // Close column
            }
        } else {
            echo "<p>No sales data available.</p>";
        }
        ?>
    </div>
</section>
<!-- End Top Selling Products -->





	




	<!-- Start FOOTER -->
    <?php include("footer.php"); ?>
    <!-- Close FOOTER -->

        <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->

   <!-- Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API=Tawk_API||{};
    Tawk_API.visitor = {
        name: '<?php echo htmlspecialchars($username); ?>', // User name from session
        email: '<?php echo htmlspecialchars($user_mail); ?>', // User email from session
        hash: '<?php echo $user_id; ?>' // Unique hash for visitor
    };

    var Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/6729e0a14304e3196add5633/1ibtpaucf';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
    <!-- End of Tawk.to Script-->


</body>
</html>

</body>

</html>