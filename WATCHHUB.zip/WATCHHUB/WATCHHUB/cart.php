<?php 
session_start();
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include("connection.php");

// Function to update cart session data
function updateCartSession($conn, $user_id) {
    $cart_query = "SELECT cart.id AS cart_id, watch.model_name, watch.price, cart.quantity, watch.id AS product_id
                   FROM cart
                   JOIN watch ON cart.watch_id = watch.id
                   WHERE cart.user_id = $user_id";
    $cart_result = $conn->query($cart_query);

    $cart_items = [];
    while ($item = $cart_result->fetch_assoc()) {
        $item['total_price'] = $item['price'] * $item['quantity'];
        $cart_items[] = $item;
    }
    // Store the cart items in the session
    $_SESSION['cart_items'] = serialize($cart_items);
}

// Initial cart session update on page load
updateCartSession($conn, $_SESSION['user_id']);

// Update cart quantity
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_cart'])) {
    $cart_id = $_POST['cart_id'];
    $new_quantity = $_POST['quantity'];
    
    // Update the cart with the new quantity
    $update_query = "UPDATE cart SET quantity = $new_quantity WHERE id = $cart_id";
    $conn->query($update_query);
    
    // Update session cart items after updating the database
    updateCartSession($conn, $_SESSION['user_id']);
    
    header("Location: cart.php");
    exit;
}

// Remove an item from the cart
if (isset($_GET['remove'])) {
    $cart_id = $_GET['remove'];
    
    // Delete the cart item
    $delete_query = "DELETE FROM cart WHERE id = $cart_id";
    $conn->query($delete_query);
    
    // Update session cart items after deletion
    updateCartSession($conn, $_SESSION['user_id']);
    
    header("Location: cart.php");
    exit;
}

// Handle checkout
if (isset($_POST['checkout'])) {
    $cart_items = unserialize($_SESSION['cart_items']);
    $insufficientStock = false;

    foreach ($cart_items as $item) {
        $product_id = $item['product_id'];
        $quantity = $item['quantity'];
        
        // Check the available stock for each product
        $stock_query = "SELECT quantity FROM watch WHERE id = $product_id";
        $stock_result = $conn->query($stock_query);
        $stock_row = $stock_result->fetch_assoc();

        if ($quantity > $stock_row['quantity']) {
            $insufficientStock = true;
            $availableStock = $stock_row['quantity'];
            echo "<script>alert('Insufficient stock for " . $item['model_name'] . ". Available: " . $availableStock . "');</script>";
        }
    }

    if (!$insufficientStock) {
        header("Location: address.php"); // Proceed to the next page
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cart</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
</head>

<body>
    <?php include("nav.php"); ?>

    <div class="container py-5">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="h2 pb-3">Your Cart</h1>
                <?php
                // Check if cart session items are empty
                if (!isset($_SESSION['cart_items']) || empty(unserialize($_SESSION['cart_items']))) {
                    echo "<p>Your cart is empty. Please add items to the cart before proceeding.</p>";
                } else {
                    $cart_items = unserialize($_SESSION['cart_items']);
                    $total_price = 0;
                ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Price</th>
                                <th scope="col">Total</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($cart_items as $item) {
                                $total = $item['total_price']; // Use total_price from the item
                                $total_price += $total;
                                echo '<tr>
                                        <td>' . $item['model_name'] . '</td>
                                        <td>
                                            <div class="input-group">
                                                <button class="btn btn-outline-secondary" type="button" onclick="updateQuantity(' . $item['cart_id'] . ', -1)">-</button>
                                                <input type="number" id="quantity_' . $item['cart_id'] . '" name="quantity" value="' . $item['quantity'] . '" min="1" class="form-control" readonly>
                                                <button class="btn btn-outline-secondary" type="button" onclick="updateQuantity(' . $item['cart_id'] . ', 1)">+</button>
                                            </div>
                                        </td>
                                        <td>$' . number_format($item['price'], 2) . '</td>
                                        <td>$' . number_format($total, 2) . '</td>
                                        <td><a href="cart.php?remove=' . $item['cart_id'] . '" class="btn btn-danger btn-sm">Remove</a></td>
                                      </tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- Promocode Section (Dummy) -->
                <form method="POST" action="cart.php" class="my-3">
                    <label for="promocode">Promocode:</label>
                    <input type="text" id="promocode" name="promocode" class="form-control d-inline w-auto" placeholder="Enter promocode">
                    <button type="submit" name="apply_promocode" class="btn btn-primary">Apply</button>
                </form>

                <div class="text-right">
                    <h3>Total: $<?php echo number_format($total_price, 2); ?></h3>
                    <form method="POST" action="cart.php"> <!-- Submit form for checkout -->
                        <button type="submit" name="checkout" class="btn btn-success">Proceed to Checkout</button>
                    </form>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>
