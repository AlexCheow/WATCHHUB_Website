<?php
session_start();
include("connection.php"); // Database connection

// Assuming user is logged in and session contains 'user_id'
$user_id = $_SESSION['user_id'];

// Fetch user's addresses
$query = "SELECT id, address FROM addresses WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$addresses = array();
while ($row = $result->fetch_assoc()) {
    $addresses[] = $row;
}

// Check if the cart has items
if (!isset($_SESSION['cart_items']) || empty(unserialize($_SESSION['cart_items']))) {
    echo "Your cart is empty. Please add items to the cart before proceeding.";
    exit();
}

// Calculate the total price from the cart items
$cart_items = unserialize($_SESSION['cart_items']);
$total_price = array_sum(array_column($cart_items, 'total_price'));

// Check if a 40% discount is applied via promocode from the previous page
$promocode_discount = isset($_SESSION['promocode_discount']) ? $_SESSION['promocode_discount'] : 0;
$discounted_total_price = $total_price * (1 - $promocode_discount / 100);

// Process checkout if cart items are confirmed
if (isset($_SESSION['checkout_cart_items'])) {
    $user_id = $_SESSION['user_id'];
    $total_price = array_sum(array_column($cart_items, 'total_price'));

    // Insert into receipts table
    $insert_receipt_query = "INSERT INTO receipts (user_id, invoice_number, total_price, delivery, created_at) VALUES
                            ($user_id, UUID(), $discounted_total_price, 'Pending', NOW())";
    $conn->query($insert_receipt_query);
    $receipt_id = $conn->insert_id;

    // Insert each item into receipt_items table
    foreach ($cart_items as $item) {
        $insert_item_query = "INSERT INTO receipt_items (receipt_id, product_id, quantity, price) VALUES
                             ($receipt_id, {$item['product_id']}, {$item['quantity']}, {$item['price']})";
        $conn->query($insert_item_query);
    }

    // Clear session data after saving
    unset($_SESSION['checkout_cart_items']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Select Delivery Address</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f4f7f6;
      color: #333;
    }
    .container {
      max-width: 800px;
      margin: 50px auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }
    h2 {
      font-weight: 600;
      margin-bottom: 20px;
    }
    .address-card {
      border: 1px solid #ddd;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }
    .address-card label {
      margin-right: 15px;
      font-weight: 500;
    }
    .btn-danger {
      background-color: #ff4c4c;
      border-color: #ff4c4c;
    }
    .btn-danger:hover {
      background-color: #ff3333;
      border-color: #ff3333;
    }
    .btn-outline-primary {
      padding: 12px 25px;
      border-radius: 8px;
      font-weight: 500;
    }
    .btn-primary {
      padding: 12px 25px;
      font-weight: 500;
    }
    .btn-primary:hover {
      transform: translateY(-2px);
    }
    .text-center {
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <a href="cart.php" class="btn btn-outline-primary mb-3">Back to Cart</a>
    <h2 class="text-center mb-4">Choose Your Delivery Address</h2>

    <!-- Address Selection Form -->
    <form id="addressForm" action="user_card.php" method="post">
      <div id="addresses-container">
        <?php
        if (empty($addresses)) {
          echo "<p>You don't have any saved addresses yet. Please add one before proceeding.</p>";
        } else {
          foreach ($addresses as $address): ?>
            <div class="address-card">
              <label>
                <input type="radio" name="selected_address" value="<?php echo $address['id']; ?>">
                <?php echo $address['address']; ?>
              </label>
              <form action="delete_address.php" method="post" style="display:inline;" id="deleteForm-<?php echo $address['id']; ?>">
                <input type="hidden" name="address_id" value="<?php echo $address['id']; ?>">
                <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete('deleteForm-<?php echo $address['id']; ?>')">Delete</button>
              </form>
            </div>
          <?php endforeach;
        }
        ?>
      </div>

      <!-- Hidden Fields to Carry Over Total, Discount, and Final Price -->
      <input type="hidden" name="total_price" value="<?php echo $total_price; ?>">
      <input type="hidden" name="promocode_discount" value="<?php echo $promocode_discount; ?>">
      <input type="hidden" name="discounted_total_price" value="<?php echo $discounted_total_price; ?>">

      <div class="d-flex justify-content-between mt-4">
        <button type="button" class="btn btn-primary" onclick="submitForm()">Proceed to Checkout</button>
        <a href="address_selection.php" class="btn btn-outline-primary">Add New Address</a>
      </div>
    </form>
  </div>

  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

  <script>
    function submitForm() {
      const selectedAddress = document.querySelector('input[name="selected_address"]:checked');
      if (!selectedAddress) {
        alert("Please select a delivery address before proceeding.");
        return;
      }
      document.getElementById('addressForm').submit();
    }

    function confirmDelete(formId) {
      // Show confirmation dialog
      const confirmation = confirm("Are you sure you want to delete this address?");
      if (confirmation) {
        document.getElementById(formId).submit(); // Submit the form if confirmed
      }
    }
  </script>
</body>
</html>
