<?php
// Include the database connection
include("connection.php");

// Function to escape and sanitize input
function escape($value) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($value));
}

// Check if the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and escape it
    $firstname = escape($_POST['firstname']);
    $lastname = escape($_POST['lastname']);
    $username = escape($_POST['username']);
	$country_code = escape($_POST['country_code']);
    $phonenumber = escape($_POST['phonenumber']);
    $email = escape($_POST['email']);
    $password = escape($_POST['password']);
    $confirm_password = escape($_POST['confirm_password']);
	
	// Concatenate country code with phone number
$full_phone_number = $country_code . $phonenumber;

    // Basic validation checks
    if (empty($firstname) || empty($lastname) || empty($username) || empty($phonenumber) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "Error: All fields are required.";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Error: Invalid email format.";
        exit;
    }

    if ($password !== $confirm_password) {
        echo "Error: Passwords do not match.";
        exit;
    }

    // Check if the email or phone number already exist in the database
    $check_query = "SELECT * FROM user WHERE mail = '$email' OR phone = '$phonenumber'";
    $result = $conn->query($check_query);

    if ($result->num_rows > 0) {
        // If email or phone number already exists, display an error message
        echo "Error: Email or phone number already exists.";
        exit;
    }

    // Check if the username already exists
    $check_username_query = "SELECT * FROM user WHERE username = '$username'";
    $username_result = $conn->query($check_username_query);

    if ($username_result->num_rows > 0) {
        // If username already exists, display an error message
        echo "Error: Username already exists.";
        exit;
    }

    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert data into the database
    $sql = "INSERT INTO user (id, firstname, lastname, username, mail, phone, password)
            VALUES (NULL, '$firstname', '$lastname', '$username', '$email', '$full_phone_number', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Registration successful
        echo '<script>alert("Registration successful. Please login."); window.location.replace("login.php");</script>';
    } else {
        // If an error occurs during insertion
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // If form was not submitted via POST
    echo "Error: Invalid form submission.";
}

// Close the database connection
$conn->close();
?>
