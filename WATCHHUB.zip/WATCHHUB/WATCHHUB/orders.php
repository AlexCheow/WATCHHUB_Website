<?php
include("connection.php");
session_start();

// Get the user ID
$user_id = $_SESSION['user_id']; // Make sure this session variable is set

// Fetch pending orders
$pending_orders_query = "SELECT r.*, d.status 
                         FROM receipts r 
                         JOIN delivery_status d ON r.receipt_id = d.receipt_id 
                         WHERE r.user_id = '$user_id' AND d.status != 'Order Arrived'
                         ORDER BY r.created_at DESC";
$pending_orders = $conn->query($pending_orders_query);

// Fetch delivered orders
$delivered_orders_query = "SELECT r.*, d.status 
                           FROM receipts r 
                           JOIN delivery_status d ON r.receipt_id = d.receipt_id 
                           WHERE r.user_id = '$user_id' AND d.status = 'Order Arrived'
                           ORDER BY r.created_at DESC";
$delivered_orders = $conn->query($delivered_orders_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Your Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<style>
        /* Make the table wider */
        .table-responsive {
            max-width: 100%;
            width: 100%;
        }
        
        /* Style for the background image */
        body {
            background-image: url("assets/img/order_background.jpg"); /* Replace with your image path */
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        
        /* Adding a light background to make the text more readable */
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 8px;
        }
		.container, .container-lg, .container-md, .container-sm, .container-xl, .container-xxl {
    max-width: 1500px;
}
    </style>
</head>
<body>
<div class="container">
    <h2 class="my-4">Your Orders</h2>

    <!-- Tabs for Pending and Delivered Orders -->
    <ul class="nav nav-tabs" id="orderTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab" aria-controls="pending" aria-selected="true">
                Pending Delivery
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="delivered-tab" data-bs-toggle="tab" data-bs-target="#delivered" type="button" role="tab" aria-controls="delivered" aria-selected="false">
                Delivered
            </button>
        </li>
    </ul>

    <!-- Tab Content -->
    <div class="tab-content" id="orderTabsContent">
        
        <!-- Pending Orders Tab -->
        <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="pending-tab">
            <?php if ($pending_orders->num_rows > 0): ?>
                <div class="table-responsive my-4">
                    <table class="table align-middle table-nowrap table-centered mb-0">
                        <thead>
                            <tr>
                                <th>Invoice Number</th>
                                <th>Total Price</th>
                                <th>Delivery Address</th>
                                <th>Order Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = $pending_orders->fetch_assoc()) { ?>
                                <tr>
                                    <td><?= $order['invoice_number'] ?></td>
                                    <td>$ <?= number_format($order['total_price'], 2) ?></td>
                                    <td><?= $order['delivery'] ?></td>
                                    <td><?= date('d/m/Y', strtotime($order['created_at'])) ?></td>
                                    <td>
                                        <a href="receipt_view.php?id=<?= $order['receipt_id'] ?>" class="btn btn-info">View Receipt</a>
                                        <a href="delivery_status.php?receipt_id=<?= $order['receipt_id'] ?>" class="btn btn-warning">Check Delivery Status</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="mt-4">No pending deliveries found.</p>
            <?php endif; ?>
        </div>

        <!-- Delivered Orders Tab -->
        <div class="tab-pane fade" id="delivered" role="tabpanel" aria-labelledby="delivered-tab">
            <?php if ($delivered_orders->num_rows > 0): ?>
                <div class="table-responsive my-4">
                    <table class="table align-middle table-nowrap table-centered mb-0">
                        <thead>
                            <tr>
                                <th>Invoice Number</th>
                                <th>Total Price</th>
                                <th>Delivery Address</th>
                                <th>Order Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = $delivered_orders->fetch_assoc()) { ?>
                                <tr>
                                    <td><?= $order['invoice_number'] ?></td>
                                    <td>$ <?= number_format($order['total_price'], 2) ?></td>
                                    <td><?= $order['delivery'] ?></td>
                                    <td><?= date('d/m/Y', strtotime($order['created_at'])) ?></td>
                                    <td>
                                        <a href="receipt_view.php?id=<?= $order['receipt_id'] ?>" class="btn btn-info">View Receipt</a>
                                        <a href="delivery_status.php?receipt_id=<?= $order['receipt_id'] ?>" class="btn btn-success">Delivery Completed</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="mt-4">No completed deliveries found.</p>
            <?php endif; ?>
        </div>
    </div>

    <a href="index.php" class="btn btn-primary my-3">Back to Home</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
