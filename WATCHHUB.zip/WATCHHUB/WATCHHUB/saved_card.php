<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include("connection.php");

    // Ensure user is logged in and retrieve user ID from session
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];

        // Sanitize and retrieve card details from the form submission
        $cardholder_name = htmlspecialchars($_POST['cardholder_name']);
        $card_number = htmlspecialchars($_POST['card_number']);
        $expiry = htmlspecialchars($_POST['expiry']);
        $cvv = htmlspecialchars($_POST['cvv']);

        // Insert card details into the user_cards table
        $query = "INSERT INTO user_cards (user_id, card_number, cardholder_name, expiration_date, cvv) VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "issss", $user_id, $card_number, $cardholder_name, $expiry, $cvv);
        
        if (mysqli_stmt_execute($stmt)) {
            // Success message for card addition
            $_SESSION['card_saved'] = "Card saved successfully.";
        } else {
            $_SESSION['card_saved'] = "Error saving card.";
        }

        // Clean up statement and connection
        mysqli_stmt_close($stmt);
        mysqli_close($conn);

        // Redirect to the user_card.php page
        header("Location: user_card.php");
        exit();
    } else {
        $_SESSION['card_saved'] = "Please log in to add a card.";
        header("Location: login.php"); // Redirect to login if user not logged in
        exit();
    }
} else {
    echo "Invalid request method.";
}
?>
