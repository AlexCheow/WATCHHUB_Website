<?php
include("connection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the username and password from the form
    $username = $_POST['username'];
    $password = $_POST['pwd'];

    // Perform database query to check user's credentials
    $query = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // User authenticated, retrieve user ID and username from the query result
        $row = $result->fetch_assoc();
        $user_id = $row['id'];
		$user_mail = $row['mail'];

        // Start the session and store user ID and username
        session_start();
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
		$_SESSION['user_mail'] = $user_mail;

        // Redirect to Home.php or perform further actions
        header('Location: index.php');
        exit;
    } else {
        // Invalid credentials, redirect back to login page with error
        $error = "Invalid username or password";
        header('Location: Login.php?error=' . urlencode($error));
        exit;
    }
}
?>
