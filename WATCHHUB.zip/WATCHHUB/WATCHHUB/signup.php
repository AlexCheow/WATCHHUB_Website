<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Sign up</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- MATERIAL DESIGN ICONIC FONT -->
    <link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

    <!-- STYLE CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <div class="wrapper" style="background-image: url('assets/img/signup_2.jpg');">
        <div class="inner">
            <div class="image-holder">
                <img src="assets/img/signup_1.jpg" alt="">
            </div>
            <form method="POST" action="signup_code.php">
                <h3>SIGN UP</h3>
                <div class="form-group">
                    <input type="text" placeholder="First Name" class="form-control" name="firstname" required>
                    <input type="text" placeholder="Last Name" class="form-control" name="lastname" required>
                </div>
                <div class="form-wrapper">
                    <input type="text" placeholder="Username" class="form-control" name="username" required>
                    <i class="zmdi zmdi-account"></i>
                </div>
                <div class="form-wrapper">
                    <input type="email" placeholder="Email Address" class="form-control" name="email" required>
                    <i class="zmdi zmdi-email"></i>
                </div>
                <div class="form-wrapper">
                    <div class="form-group">
                        <select class="form-control" style="width: 30%; display: inline-block;" name="country_code" required>
                            <option value="" disabled selected>Country Code</option>
                            <option value="+1">+1 (USA)</option>
                            <option value="+44">+44 (UK)</option>
                            <option value="+61">+61 (Australia)</option>
                            <option value="+60">+60 (Malaysia)</option>
                            <!-- Add more country codes here -->
                        </select>
                        <br/>
                        <input type="text" placeholder="Phone Number" class="form-control" style="width: 68%; display: inline-block;" name="phonenumber" required>
                    </div>
                </div>
                <div class="form-wrapper">
                    <input type="password" placeholder="Password" class="form-control" name="password" required>
                    <i class="zmdi zmdi-lock"></i>
                </div>
                <div class="form-wrapper">
                    <input type="password" placeholder="Confirm Password" class="form-control" name="confirm_password" required>
                    <i class="zmdi zmdi-lock"></i>
                </div>
                <button>Register
                    <i class="zmdi zmdi-arrow-right"></i>
                </button>
            </form>
        </div>
    </div>
    
</body>
</html>
