<?php
// add_to_cart.php
session_start();
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit;
}


include("connection.php");

$user_id = $_SESSION['user_id']; // Assuming the user is logged in
$watch_id = $_GET['id']; // From form
$quantity = 1; // From form

// Check if item already exists in cart
$check_cart_query = "SELECT * FROM cart WHERE user_id = $user_id AND watch_id = $watch_id";
$check_cart_result = $conn->query($check_cart_query);

if ($check_cart_result->num_rows > 0) {
    // Update quantity if already in cart
    $update_cart_query = "UPDATE cart SET quantity = quantity + $quantity WHERE user_id = $user_id AND watch_id = $watch_id";
    $conn->query($update_cart_query);
} else {
    // Add new item to cart
    $insert_cart_query = "INSERT INTO cart (user_id, watch_id, quantity) VALUES ($user_id, $watch_id, $quantity)";
    $conn->query($insert_cart_query);
}

header("Location: cart.php"); // Redirect to cart page
?>
