<?php
session_start();
include("connection.php"); // Database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Get the address ID to delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['address_id'])) {
    $address_id = $_POST['address_id'];
    $user_id = $_SESSION['user_id'];

    // Prepare the delete statement
    $query = "DELETE FROM addresses WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $address_id, $user_id);
    
    if ($stmt->execute()) {
        // Address deleted successfully
        $_SESSION['message'] = "Address deleted successfully.";
    } else {
        // Handle error
        $_SESSION['message'] = "Error deleting address.";
    }

    $stmt->close();
}

// Redirect back to the address selection page
header("Location: address.php");
exit();
?>
