<?php
include("connection.php");

// Fetch all brands from the brand table
$brand_query = "SELECT id, name FROM brand";
$brands = $conn->query($brand_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Stock Adjustment</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // Fetch products by brand from PHP and store in JavaScript
        const productsByBrand = {
            <?php
            $brand_products_query = "SELECT id, model_name, brand_id FROM watch WHERE status = 'active'";
            $product_results = $conn->query($brand_products_query);
            $products = [];
            while ($product = $product_results->fetch_assoc()) {
                $products[$product['brand_id']][] = $product;
            }
            foreach ($products as $brandId => $productList) {
                echo "'$brandId': " . json_encode($productList) . ",";
            }
            ?>
        };

        // Function to populate products based on selected brand
        function updateProductOptions(selectElement) {
            const brandId = selectElement.value;
            const productSelect = selectElement.closest('tr').querySelector('.product-select');

            // Clear current options
            productSelect.innerHTML = '<option value="">Select Product</option>';

            // Populate products for the selected brand
            if (productsByBrand[brandId]) {
                productsByBrand[brandId].forEach(product => {
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = product.model_name;
                    productSelect.appendChild(option);
                });
            }
        }

        // Function to add a new row for product adjustment
        function addAdjustmentRow() {
            const adjustmentTable = document.getElementById('adjustmentTableBody');
            const rowCount = adjustmentTable.rows.length;
            const newRow = adjustmentTable.insertRow(rowCount);

            newRow.innerHTML = `
                <tr>
                    <td>
                        <select class="form-control brand-select" onchange="updateProductOptions(this)" required>
                            <option value="">Select Brand</option>
                            <?php while ($brand = $brands->fetch_assoc()) { ?>
                                <option value="<?php echo $brand['id']; ?>"><?php echo $brand['name']; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td>
                        <select class="form-control product-select" name="product_ids[]" required>
                            <option value="">Select Product</option>
                        </select>
                    </td>
                    <td><input type="number" class="form-control" name="quantities[]" placeholder="Quantity Adjusted" required></td>
                    <td><textarea class="form-control" name="descriptions[]" rows="2" placeholder="Description"></textarea></td>
                    <td><button type="button" class="btn btn-danger btn-sm" onclick="removeAdjustmentRow(this)">Remove</button></td>
                </tr>
            `;
        }

        // Function to remove a row
        function removeAdjustmentRow(button) {
            const row = button.parentNode.parentNode;
            row.parentNode.removeChild(row);
        }
    </script>
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Add Stock Adjustment</h2>

    <form action="process_adjustment.php" method="POST">
        <!-- Title for Stock Control -->
        <div class="form-group">
            <label for="title">Adjustment Title:</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>

        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Brand</th>
                    <th>Product</th>
                    <th>Quantity Adjusted</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="adjustmentTableBody">
                <!-- Initial adjustment row -->
                <tr>
                    <td>
                        <select class="form-control brand-select" onchange="updateProductOptions(this)" required>
                            <option value="">Select Brand</option>
                            <?php
                            $brands = $conn->query($brand_query); // Reset brand query result
                            while ($brand = $brands->fetch_assoc()) { ?>
                                <option value="<?php echo $brand['id']; ?>"><?php echo $brand['name']; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td>
                        <select class="form-control product-select" name="product_ids[]" required>
                            <option value="">Select Product</option>
                        </select>
                    </td>
                    <td><input type="number" class="form-control" name="quantities[]" placeholder="Quantity Adjusted" required></td>
                    <td><textarea class="form-control" name="descriptions[]" rows="2" placeholder="Description"></textarea></td>
                    <td><button type="button" class="btn btn-danger btn-sm" onclick="removeAdjustmentRow(this)">Remove</button></td>
                </tr>
            </tbody>
        </table>

        <div class="button-container">
            <button type="button" class="btn btn-secondary" onclick="addAdjustmentRow()">Add New Item</button>
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="stock_adjustment_list.php" class="btn btn-light">Cancel</a>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
