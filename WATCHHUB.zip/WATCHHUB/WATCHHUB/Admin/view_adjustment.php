<?php
include("connection.php");

$stock_control_id = $_GET['id'];

// Fetch stock control details
$stock_control_query = "SELECT * FROM stock_control WHERE id = $stock_control_id";
$stock_control_result = $conn->query($stock_control_query);
$stock_control = $stock_control_result->fetch_assoc();

// Fetch adjusted products with brand information
$product_query = "SELECT b.name AS brand_name, p.model_name, scp.product_id, scp.descriptions AS product_description, scp.quantity_adjusted, p.price, 
                     p.quantity AS 'Unit of Measure', 'Inventory Adjustment' AS adjustment_account, 'i8 - ISLAND 88 MALL' AS location
                  FROM stock_control_products scp
                  JOIN watch p ON scp.product_id = p.id
                  JOIN brand b ON p.brand_id = b.id
                  WHERE scp.stock_control_id = $stock_control_id";
$products = $conn->query($product_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Stock Adjustment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // Function to confirm and delete the stock adjustment
        function confirmDelete(stockControlId) {
            if (confirm("Are you sure you want to delete this stock adjustment? This action cannot be undone.")) {
                window.location.href = "delete_adjustment.php?id=" + stockControlId;
            }
        }
    </script>
</head>
<body>
    <div class="container my-4">
        <h1 class="mb-4">Stock Adjustment Details</h1>
        
        <div class="card mb-4">
            <div class="card-body">
                <p><strong>Title:</strong> <?php echo htmlspecialchars($stock_control['title']); ?></p>
                <p><strong>Date:</strong> <?php echo date('d/m/Y', strtotime($stock_control['created_at'])); ?></p>
            </div>
        </div>

        <h3 class="mb-3">Adjusted Products:</h3>
        <table class="table table-striped table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Brand</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Quantity Adjusted</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $grandTotal = 0;
                while ($product = $products->fetch_assoc()):
                    $amount = $product['quantity_adjusted'] * $product['price'];
                    $grandTotal += $amount;
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['brand_name']); ?></td>
                        <td><?php echo htmlspecialchars($product['model_name']); ?></td>
                        <td><?php echo htmlspecialchars($product['product_description']); ?></td>
                        <td><?php echo htmlspecialchars($product['quantity_adjusted']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div class="d-flex justify-content-end mt-3">
            <button onclick="window.location.href='add_stock.php'" class="btn btn-primary me-2">Back to List</button>
            <button onclick="confirmDelete(<?php echo $stock_control_id; ?>)" class="btn btn-danger">Delete</button>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
