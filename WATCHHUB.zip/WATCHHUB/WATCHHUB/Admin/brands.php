<?php
include("connection.php");
session_start();

// Handle form submission to add a new brand
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_brand'])) {
    $brand_name = $_POST['brand_name'];

    // Insert the new brand into the database with an active status
    $query = "INSERT INTO brand (name, status) VALUES (?, 'active')";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $brand_name);

    if (mysqli_stmt_execute($stmt)) {
        // Redirect back to the page to refresh the list without showing any message
        header("Location: brands.php");
        exit();
    }
}

// Handle activation and deactivation of a brand
if (isset($_GET['toggle_status'])) {
    $brand_id = $_GET['toggle_status'];
    
    // Check current status of the brand
    $status_query = "SELECT status FROM brand WHERE id = ?";
    $status_stmt = mysqli_prepare($conn, $status_query);
    mysqli_stmt_bind_param($status_stmt, "i", $brand_id);
    mysqli_stmt_execute($status_stmt);
    $status_result = mysqli_stmt_get_result($status_stmt);
    $brand = mysqli_fetch_assoc($status_result);
    
    // Toggle status based on current status
    $new_status = ($brand['status'] == 'active') ? 'inactive' : 'active';

    $toggle_query = "UPDATE brand SET status = ? WHERE id = ?";
    $toggle_stmt = mysqli_prepare($conn, $toggle_query);
    mysqli_stmt_bind_param($toggle_stmt, "si", $new_status, $brand_id);

    if (mysqli_stmt_execute($toggle_stmt)) {
        // Redirect back to the page to refresh the list without showing any message
        header("Location: brands.php");
        exit();
    }
}

// Fetch all brands from the database
$query = "SELECT id, name, status FROM brand";
$result = mysqli_query($conn, $query);
$brands = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Brands</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<?php include("nav.php"); ?>
</head>
<body>
<div class="container mt-5">
    <h2>Manage Brands</h2>

    <!-- Form to add a new brand -->
    <form action="brands.php" method="POST" class="mb-4">
        <div class="input-group">
            <input type="text" name="brand_name" class="form-control" placeholder="Enter brand name" required>
            <button type="submit" name="add_brand" class="btn btn-primary">Add Brand</button>
        </div>
    </form>

    <!-- Display all brands in a table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Brand Name</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($brands as $brand): ?>
                <tr>
                    <td><?php echo $brand['id']; ?></td>
                    <td><?php echo htmlspecialchars($brand['name']); ?></td>
                    <td><?php echo ucfirst($brand['status']); ?></td>
                    <td>
                        <?php if ($brand['status'] == 'active'): ?>
                            <a href="brands.php?toggle_status=<?php echo $brand['id']; ?>" class="btn btn-warning btn-sm">Deactivate</a>
                        <?php else: ?>
                            <a href="brands.php?toggle_status=<?php echo $brand['id']; ?>" class="btn btn-success btn-sm">Activate</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
