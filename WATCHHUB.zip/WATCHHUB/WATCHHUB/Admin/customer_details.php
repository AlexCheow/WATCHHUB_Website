<?php
include("connection.php");
session_start();

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    
    // Fetch customer details
    $queryCustomer = "SELECT firstname, lastname, mail, phone FROM user WHERE id = ?";
    $stmtCustomer = mysqli_prepare($conn, $queryCustomer);
    mysqli_stmt_bind_param($stmtCustomer, "i", $user_id);
    mysqli_stmt_execute($stmtCustomer);
    $resultCustomer = mysqli_stmt_get_result($stmtCustomer);
    $customer = mysqli_fetch_assoc($resultCustomer);

    // Fetch customer purchase details
    $queryReceipts = "
        SELECT r.invoice_number, r.total_price, r.created_at
        FROM receipts r
        WHERE r.user_id = ?
        ORDER BY r.created_at DESC";
    $stmtReceipts = mysqli_prepare($conn, $queryReceipts);
    mysqli_stmt_bind_param($stmtReceipts, "i", $user_id);
    mysqli_stmt_execute($stmtReceipts);
    $resultReceipts = mysqli_stmt_get_result($stmtReceipts);
    $receipts = mysqli_fetch_all($resultReceipts, MYSQLI_ASSOC);
} else {
    echo "No customer selected.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Details - <?php echo htmlspecialchars($customer['firstname'] . " " . $customer['lastname']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<?php include("nav.php"); ?>
</head>
<body>
<div class="container mt-5">
    <h2>Customer Details</h2>
    <p><strong>Customer Name:</strong> <?php echo htmlspecialchars($customer['firstname'] . " " . $customer['lastname']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($customer['mail']); ?></p>
    <p><strong>Phone:</strong> <?php echo htmlspecialchars($customer['phone']); ?></p>

    <h3 class="mt-4">Purchase History</h3>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Invoice Number</th>
                <th>Total Purchase Price</th>
                <th>Purchase Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($receipts)): ?>
                <?php foreach ($receipts as $receipt): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($receipt['invoice_number']); ?></td>
                        <td>$<?php echo number_format($receipt['total_price'], 2); ?></td>
                        <td><?php echo htmlspecialchars($receipt['created_at']); ?></td>
                        <td>
                            <a href="view_receipt.php?invoice=<?php echo $receipt['invoice_number']; ?>" class="btn btn-primary">View Receipt</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">No purchase history available for this customer.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
