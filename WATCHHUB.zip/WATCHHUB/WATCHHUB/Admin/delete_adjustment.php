<?php
include("connection.php");

$stock_control_id = $_GET['id'];

// Fetch the adjusted products to restore the quantities
$product_query = "SELECT product_id, quantity_adjusted FROM stock_control_products WHERE stock_control_id = $stock_control_id";
$products = $conn->query($product_query);

while ($product = $products->fetch_assoc()) {
    $product_id = $product['product_id'];
    $quantity_adjusted = $product['quantity_adjusted'];
    
    // Update the quantity in the watch table
    $update_query = "UPDATE watch SET quantity = quantity - $quantity_adjusted WHERE id = $product_id";
    $conn->query($update_query);
}

// Delete the records from stock_control_products for this adjustment
$delete_products_query = "DELETE FROM stock_control_products WHERE stock_control_id = $stock_control_id";
$conn->query($delete_products_query);

// Delete the stock_control record itself
$delete_control_query = "DELETE FROM stock_control WHERE id = $stock_control_id";
$conn->query($delete_control_query);

// Redirect back to the list with a success message
header("Location: add_stock.php?message=Stock adjustment deleted successfully");
exit;
?>
