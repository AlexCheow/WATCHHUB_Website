<style>
	* { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; display: flex; }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #333;
            color: #fff;
            height: 100vh;
            position: fixed;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar a {
            padding: 15px 20px;
            text-decoration: none;
            color: #ddd;
            display: block;
        }
        .sidebar a:hover {
            background-color: #444;
            color: #fff;
        }

        /* Main content styling */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: 100%;
        }

        .chart-container {
            margin-bottom: 40px;
        }
</style>

<!-- Sidebar Navigation -->
<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="index.php">Dashboard</a>
	<a href="sales_report.php">Sales Report</a>
    <a href="orders.php">Orders</a>
	<a href="brands.php">Brands</a>
    <a href="products.php">Products</a>
    <a href="customers.php">Customers</a>
    <a href="add_stock.php">Stock</a>
</div>