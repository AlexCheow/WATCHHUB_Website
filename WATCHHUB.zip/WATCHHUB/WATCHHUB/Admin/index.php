<?php
include("connection.php");

// Fetch sales data and top products data
$salesData = [];
$topProducts = [];

// Fetch monthly sales totals
$salesQuery = "SELECT DATE_FORMAT(created_at, '%Y-%m') AS sale_month, SUM(total_price) AS total_sales 
               FROM receipts GROUP BY sale_month ORDER BY sale_month";
$result = mysqli_query($conn, $salesQuery);
$totalSales = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $salesData[] = $row;
    $totalSales += $row['total_sales'];
}

// Fetch top-selling products
$topProductQuery = "SELECT w.model_name, SUM(ri.quantity) AS total_sold
                    FROM receipt_items ri
                    JOIN watch w ON ri.product_id = w.id
                    GROUP BY w.model_name ORDER BY total_sold DESC";
$result = mysqli_query($conn, $topProductQuery);

while ($row = mysqli_fetch_assoc($result)) {
    $topProducts[] = $row;
}

// Fetch Men's stock data with total value
$menStockData = [];
$menStockQuery = "SELECT model_name, quantity, price FROM watch WHERE gender = 'Men' AND quantity > 0";
$result = mysqli_query($conn, $menStockQuery);

while ($row = mysqli_fetch_assoc($result)) {
    $menStockData[] = $row;
}

// Fetch Women's stock data with total value
$womenStockData = [];
$womenStockQuery = "SELECT model_name, quantity, price FROM watch WHERE gender = 'Women' AND quantity > 0";
$result = mysqli_query($conn, $womenStockQuery);

while ($row = mysqli_fetch_assoc($result)) {
    $womenStockData[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include("nav.php"); ?>
    <style>
        .chart-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
            margin: 20px 0;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .chart {
            width: 90%;
            max-width: 600px;
            height: 350px;
        }
        .divider-horizontal {
            border-top: 3px solid #444;
            margin: 40px 0;
        }
        h3 {
            font-size: 1.5rem;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container my-5">
    <h2 class="text-center mb-5">Admin Dashboard</h2>

    <!-- Row 1: Monthly Sales Chart and Top Selling Products Chart -->
    <div class="row">
        <div class="col-md-6 chart-container">
            <h3>Monthly Sales</h3>
            <canvas id="salesChart" class="chart"></canvas>
        </div>
        <div class="col-md-6 chart-container">
            <h3>Top Selling Products</h3>
            <canvas id="topProductsChart" class="chart"></canvas>
        </div>
    </div>

    <div class="divider-horizontal"></div>

    <!-- Row 2: Men's Stock Bar Chart and Women's Stock Bar Chart -->
    <div class="row">
        <div class="col-md-6 chart-container">
            <h3>Men's Stock Distribution</h3>
            <canvas id="menStockChart" class="chart"></canvas>
        </div>
        <div class="col-md-6 chart-container">
            <h3>Women's Stock Distribution</h3>
            <canvas id="womenStockChart" class="chart"></canvas>
        </div>
    </div>

    <div class="divider-horizontal"></div>

    <!-- Tabs Section -->
    <ul class="nav nav-tabs" id="summaryTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" id="sales-summary-tab" data-bs-toggle="tab" href="#sales-summary" role="tab" aria-controls="sales-summary" aria-selected="true">Sales Summary</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="top-selling-summary-tab" data-bs-toggle="tab" href="#top-selling-summary" role="tab" aria-controls="top-selling-summary" aria-selected="false">Top Selling Summary</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="stock-on-hand-tab" data-bs-toggle="tab" href="#stock-on-hand" role="tab" aria-controls="stock-on-hand" aria-selected="false">Stock On Hand</a>
        </li>
    </ul>

    <div class="tab-content p-4 border rounded-bottom">
        <!-- Sales Summary Tab -->
        <div class="tab-pane fade show active" id="sales-summary" role="tabpanel" aria-labelledby="sales-summary-tab">
            <h4>Sales Summary</h4>
            <p><strong>Total Sales:</strong> $<?php echo number_format($totalSales, 2); ?></p>
        </div>

        <!-- Top Selling Summary Tab -->
        <div class="tab-pane fade" id="top-selling-summary" role="tabpanel" aria-labelledby="top-selling-summary-tab">
            <h4>Top Selling Summary</h4>
            <ul>
                <?php foreach ($topProducts as $rank => $product): ?>
                    <li>
                        Rank <?php echo $rank + 1; ?>: 
                        <?php echo htmlspecialchars($product['model_name']); ?> - <?php echo $product['total_sold']; ?> units sold
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Stock On Hand Tab -->
        <div class="tab-pane fade" id="stock-on-hand" role="tabpanel" aria-labelledby="stock-on-hand-tab">
            <h4>Stock On Hand</h4>
            <div class="row">
                <!-- Men's Stock Details -->
                <div class="col-md-6">
                    <h5>Men's Stock</h5>
                    <ul>
                        <?php 
                        $totalMenUnits = 0;
                        $totalMenValue = 0;
                        foreach ($menStockData as $product): 
                            $productTotalValue = $product['quantity'] * $product['price'];
                            $totalMenUnits += $product['quantity'];
                            $totalMenValue += $productTotalValue;
                        ?>
                            <li>
                                <?php echo htmlspecialchars($product['model_name']); ?> - 
                                <?php echo $product['quantity']; ?> units - 
                                $<?php echo number_format($product['price'], 2); ?> each - 
                                Total: $<?php echo number_format($productTotalValue, 2); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <p><strong>Total Men's Units:</strong> <?php echo $totalMenUnits; ?> units</p>
                    <p><strong>Total Men's Stock Value:</strong> $<?php echo number_format($totalMenValue, 2); ?></p>
                </div>

                <!-- Women's Stock Details -->
                <div class="col-md-6">
                    <h5>Women's Stock</h5>
                    <ul>
                        <?php 
                        $totalWomenUnits = 0;
                        $totalWomenValue = 0;
                        foreach ($womenStockData as $product): 
                            $productTotalValue = $product['quantity'] * $product['price'];
                            $totalWomenUnits += $product['quantity'];
                            $totalWomenValue += $productTotalValue;
                        ?>
                            <li>
                                <?php echo htmlspecialchars($product['model_name']); ?> - 
                                <?php echo $product['quantity']; ?> units - 
                                $<?php echo number_format($product['price'], 2); ?> each - 
                                Total: $<?php echo number_format($productTotalValue, 2); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <p><strong>Total Women's Units:</strong> <?php echo $totalWomenUnits; ?> units</p>
                    <p><strong>Total Women's Stock Value:</strong> $<?php echo number_format($totalWomenValue, 2); ?></p>
                </div>
            </div>

            <!-- Overall Totals -->
            <div class="mt-4">
                <h5>Overall Totals</h5>
                <p><strong>Total Units:</strong> <?php echo $totalMenUnits + $totalWomenUnits; ?> units</p>
                <p><strong>Total Stock Value:</strong> $<?php echo number_format($totalMenValue + $totalWomenValue, 2); ?></p>
            </div>
        </div>
    </div>
</div>

<script>
// Sales Chart
const salesLabels = <?php echo json_encode(array_column($salesData, 'sale_month')); ?>;
const salesValues = <?php echo json_encode(array_column($salesData, 'total_sales')); ?>;

const salesCtx = document.getElementById('salesChart').getContext('2d');
const salesChart = new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: salesLabels,
        datasets: [{
            label: 'Monthly Sales ($)',
            data: salesValues,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }]
    },
    options: { responsive: true }
});

// Top Selling Products Chart
const productLabels = <?php echo json_encode(array_column($topProducts, 'model_name')); ?>;
const productValues = <?php echo json_encode(array_column($topProducts, 'total_sold')); ?>;

const topProductsCtx = document.getElementById('topProductsChart').getContext('2d');
const topProductsChart = new Chart(topProductsCtx, {
    type: 'bar',
    data: {
        labels: productLabels,
        datasets: [{
            label: 'Units Sold',
            data: productValues,
            backgroundColor: 'rgba(153, 102, 255, 0.2)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1
        }]
    },
    options: { responsive: true }
});

// Men's Stock Bar Chart
const menLabels = <?php echo json_encode(array_column($menStockData, 'model_name')); ?>;
const menQuantities = <?php echo json_encode(array_column($menStockData, 'quantity')); ?>;

const menStockCtx = document.getElementById('menStockChart').getContext('2d');
const menStockChart = new Chart(menStockCtx, {
    type: 'bar',
    data: {
        labels: menLabels,
        datasets: [{
            label: "Men's Stock",
            data: menQuantities,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: { responsive: true }
});

// Women's Stock Bar Chart
const womenLabels = <?php echo json_encode(array_column($womenStockData, 'model_name')); ?>;
const womenQuantities = <?php echo json_encode(array_column($womenStockData, 'quantity')); ?>;

const womenStockCtx = document.getElementById('womenStockChart').getContext('2d');
const womenStockChart = new Chart(womenStockCtx, {
    type: 'bar',
    data: {
        labels: womenLabels,
        datasets: [{
            label: "Women's Stock",
            data: womenQuantities,
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    },
    options: { responsive: true }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
