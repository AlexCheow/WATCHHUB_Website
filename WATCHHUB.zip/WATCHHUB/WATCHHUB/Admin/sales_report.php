<?php
include("connection.php");

// Check if a date range was submitted
$reportData = [];
$totalSalesInRange = 0;
$fromDate = $toDate = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['from_date'], $_POST['to_date'])) {
    $fromDate = $_POST['from_date'];
    $toDate = $_POST['to_date'];

    // Query to get total sales within the selected date range
    $salesQuery = "SELECT SUM(r.total_price) AS total_sales
                   FROM receipts r
                   WHERE r.created_at BETWEEN '$fromDate' AND '$toDate'";
    $salesResult = mysqli_query($conn, $salesQuery);
    $totalSalesInRange = mysqli_fetch_assoc($salesResult)['total_sales'];

    // Query to get products sold with quantity and price within the selected date range
    $productSalesQuery = "SELECT w.model_name, SUM(ri.quantity) AS quantity_sold, w.price
                          FROM receipt_items ri
                          JOIN watch w ON ri.product_id = w.id
                          JOIN receipts r ON ri.receipt_id = r.receipt_id
                          WHERE r.created_at BETWEEN '$fromDate' AND '$toDate'
                          GROUP BY w.model_name, w.price
                          ORDER BY quantity_sold DESC";
    $productSalesResult = mysqli_query($conn, $productSalesQuery);

    while ($row = mysqli_fetch_assoc($productSalesResult)) {
        $reportData[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include("nav.php"); ?>
</head>
<body>

<div class="container my-5">
    <h2>Admin Dashboard</h2>

    <!-- Date Range Form for Generating Sales Report -->
    <div class="mt-4 p-3 bg-light border rounded">
        <h3>Generate Sales Report</h3>
        <form method="POST" action="">
            <div class="row">
                <div class="col-md-5">
                    <label for="from_date" class="form-label">From Date:</label>
                    <input type="date" id="from_date" name="from_date" class="form-control" required>
                </div>
                <div class="col-md-5">
                    <label for="to_date" class="form-label">To Date:</label>
                    <input type="date" id="to_date" name="to_date" class="form-control" required>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Generate Report</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Display Sales Report if Date Range is Selected -->
    <?php if (!empty($reportData)): ?>
        <div class="mt-5 p-3 bg-light border rounded">
            <h3>Sales Report (<?php echo htmlspecialchars($fromDate); ?> to <?php echo htmlspecialchars($toDate); ?>)</h3>
            <p><strong>Total Sales:</strong> $<?php echo number_format($totalSalesInRange, 2); ?></p>

            <h5>Products Sold by Rank:</h5>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Product</th>
                        <th>Quantity Sold</th>
                        <th>Price per Unit</th>
                        <th>Total Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rank = 1;
                    foreach ($reportData as $row): 
                        $totalRevenue = $row['quantity_sold'] * $row['price'];
                    ?>
                        <tr>
                            <td><?php echo $rank++; ?></td>
                            <td><?php echo htmlspecialchars($row['model_name']); ?></td>
                            <td><?php echo $row['quantity_sold']; ?></td>
                            <td>$<?php echo number_format($row['price'], 2); ?></td>
                            <td>$<?php echo number_format($totalRevenue, 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Download PDF Button -->
            <form method="POST" action="generate_pdf.php" target="_blank">
                <input type="hidden" name="from_date" value="<?php echo $fromDate; ?>">
                <input type="hidden" name="to_date" value="<?php echo $toDate; ?>">
                <input type="hidden" name="report_data" value="<?php echo htmlspecialchars(json_encode($reportData)); ?>">
                <input type="hidden" name="total_sales" value="<?php echo $totalSalesInRange; ?>">
                <button type="submit" class="btn btn-danger mt-3">Download PDF</button>
            </form>
        </div>
    <?php elseif ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        <p class="mt-4">No sales data found for the selected date range.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
