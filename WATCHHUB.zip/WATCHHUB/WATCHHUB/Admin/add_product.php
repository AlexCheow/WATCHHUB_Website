<?php
include("connection.php");
session_start();

// Fetch brands for dropdown
$queryBrands = "SELECT id, name FROM brand";
$resultBrands = mysqli_query($conn, $queryBrands);
$brands = mysqli_fetch_all($resultBrands, MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $brand_id = $_POST['brand_id'];
    $model_name = $_POST['model_name'];
    $gender = $_POST['gender'];
    $case_material = $_POST['case_material'];
    $movement_type = $_POST['movement_type'];
    $strap_material = $_POST['strap_material'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $specification = $_POST['specification'];
    $quantity = 0;  // Set quantity to 0

    
    $image = $_FILES['image_url']['tmp_name'];
    $imageData = file_get_contents($image); // Convert image to binary

    // Insert into database
    $query = "INSERT INTO watch (brand_id, model_name, gender, case_material, movement_type, strap_material, price, image_url, description, specification, quantity) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "isssssdsssi", $brand_id, $model_name, $gender, $case_material, $movement_type, $strap_material, $price, $imageData, $description, $specification, $quantity);

    if (mysqli_stmt_execute($stmt)) {
        echo "<div class='alert alert-success'>Product added successfully!<script>window.location.href='products.php';</script></div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Add New Product</h2>
    <form action="add_product.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="brand_id" class="form-label">Brand</label>
            <select name="brand_id" id="brand_id" class="form-control" required>
                <option value="">Select Brand</option>
                <?php foreach ($brands as $brand): ?>
                    <option value="<?php echo $brand['id']; ?>"><?php echo $brand['name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="model_name" class="form-label">Model Name</label>
            <input type="text" name="model_name" id="model_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="gender" class="form-label">Gender</label>
            <select name="gender" id="gender" class="form-control" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Unisex">Unisex</option>
            </select>
        </div>
        <div class="mb-3">
    <label for="case_material" class="form-label">Case Material</label>
    <select name="case_material" id="case_material" class="form-control" required>
        <option value="Steel">Steel</option>
        <option value="Plastic">Plastic</option>
        <option value="Leather">Leather</option>
    </select>
</div>

<div class="mb-3">
    <label for="movement_type" class="form-label">Movement Type</label>
    <select name="movement_type" id="movement_type" class="form-control" required>
        <option value="Automatic">Automatic</option>
        <option value="Quartz">Quartz</option>
    </select>
</div>

        <div class="mb-3">
            <label for="strap_material" class="form-label">Strap Material</label>
            <input type="text" name="strap_material" id="strap_material" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="number" step="0.01" name="price" id="price" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="image_url" class="form-label">Image</label>
            <input type="file" name="image_url" id="image_url" class="form-control" accept="image/jpeg" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea name="description" id="description" class="form-control" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="specification" class="form-label">Specification</label>
            <textarea name="specification" id="specification" class="form-control" rows="3" required></textarea>
        </div>

        <!-- Quantity field removed from the form -->

        <button type="submit" class="btn btn-primary">Add Product</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
