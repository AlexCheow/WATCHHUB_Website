<?php
require 'vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['from_date'], $_POST['to_date'])) {
    $fromDate = $_POST['from_date'];
    $toDate = $_POST['to_date'];

    // Fetch sales data for the selected date range
    $reportData = [];
    $totalSalesInRange = 0;

    $reportQuery = "SELECT w.model_name, SUM(ri.quantity) AS total_quantity, w.price AS unit_price, 
                    SUM(ri.quantity * w.price) AS total_price 
                    FROM receipts r
                    JOIN receipt_items ri ON r.receipt_id = ri.receipt_id
                    JOIN watch w ON ri.product_id = w.id
                    WHERE r.created_at BETWEEN '$fromDate' AND '$toDate'
                    GROUP BY w.model_name
                    ORDER BY total_quantity DESC";

    $reportResult = mysqli_query($conn, $reportQuery);

    while ($row = mysqli_fetch_assoc($reportResult)) {
        $reportData[] = $row;
        $totalSalesInRange += $row['total_price'];
    }

    // Generate PDF
    $options = new Options();
    $options->set('isRemoteEnabled', true);
    $dompdf = new Dompdf($options);

    $html = '<h1>Sales Report</h1>';
    $html .= "<p><strong>Date Range:</strong> $fromDate to $toDate</p>";
    $html .= "<p><strong>Total Sales:</strong> $" . number_format($totalSalesInRange, 2) . "</p>";
    $html .= "<table border='1' cellpadding='5' cellspacing='0' width='100%'>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity Sold</th>
                        <th>Unit Price</th>
                        <th>Total Sales</th>
                    </tr>
                </thead>
                <tbody>";

    foreach ($reportData as $row) {
        $html .= "<tr>
                    <td>{$row['model_name']}</td>
                    <td>{$row['total_quantity']}</td>
                    <td>$" . number_format($row['unit_price'], 2) . "</td>
                    <td>$" . number_format($row['total_price'], 2) . "</td>
                </tr>";
    }

    $html .= "  </tbody>
            </table>";

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    // Send the PDF for download
    $dompdf->stream("Sales_Report_$fromDate-$toDate.pdf", ["Attachment" => 1]);
}
?>
