<?php
include("connection.php");
session_start();

if (isset($_GET['invoice'])) {
    $invoice_number = $_GET['invoice'];

    // Fetch receipt details based on the invoice number
    $queryReceipt = "SELECT r.receipt_id, r.total_price, r.created_at, r.delivery FROM receipts r WHERE r.invoice_number = ?";
    $stmtReceipt = mysqli_prepare($conn, $queryReceipt);
    mysqli_stmt_bind_param($stmtReceipt, "s", $invoice_number);
    mysqli_stmt_execute($stmtReceipt);
    $resultReceipt = mysqli_stmt_get_result($stmtReceipt);
    $receipt = mysqli_fetch_assoc($resultReceipt);

    // Fetch the items associated with the receipt
    $queryItems = "
        SELECT w.model_name, ri.quantity, ri.price
        FROM receipt_items ri
        JOIN watch w ON ri.product_id = w.id
        WHERE ri.receipt_id = ?";
    $stmtItems = mysqli_prepare($conn, $queryItems);
    mysqli_stmt_bind_param($stmtItems, "i", $receipt['receipt_id']);
    mysqli_stmt_execute($stmtItems);
    $resultItems = mysqli_stmt_get_result($stmtItems);
    $items = mysqli_fetch_all($resultItems, MYSQLI_ASSOC);
} else {
    echo "No invoice selected.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt Details - Invoice #<?php echo htmlspecialchars($invoice_number); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Receipt Details</h2>
    <h4>Invoice Number: <?php echo htmlspecialchars($invoice_number); ?></h4>
    <p><strong>Total Price:</strong> $<?php echo number_format($receipt['total_price'], 2); ?></p>
    <p><strong>Purchase Date:</strong> <?php echo htmlspecialchars($receipt['created_at']); ?></p>
    <p><strong>Delivery Address:</strong> <?php echo htmlspecialchars($receipt['delivery']); ?></p>

    <h3 class="mt-4">Items Purchased</h3>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($items)): ?>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['model_name']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td>$<?php echo number_format($item['price'], 2); ?></td>
                        <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">No items found for this receipt.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="mt-4">
        <a href="customer_details.php?user_id=<?php echo htmlspecialchars($customer['id']); ?>" class="btn btn-secondary">Back to Customer Details</a>
    </div>
</div>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
