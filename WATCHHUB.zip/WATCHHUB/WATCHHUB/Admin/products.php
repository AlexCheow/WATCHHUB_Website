<?php
include("connection.php");
session_start();

// Initialize variables for search and filter
$search = isset($_GET['search']) ? $_GET['search'] : '';
$brand_filter = isset($_GET['brand']) ? $_GET['brand'] : '';
$gender_filter = isset($_GET['gender']) ? $_GET['gender'] : '';
$price_filter = isset($_GET['price']) ? $_GET['price'] : '';

// Fetch brands for the filter dropdown
$queryBrands = "SELECT id, name FROM brand";
$resultBrands = mysqli_query($conn, $queryBrands);
$brands = mysqli_fetch_all($resultBrands, MYSQLI_ASSOC);

// Construct the query based on filters and search
$query = "SELECT w.*, b.name AS brand_name FROM watch w
          JOIN brand b ON w.brand_id = b.id
          WHERE (w.model_name LIKE ? OR b.name LIKE ?)";
$params = ["%$search%", "%$search%"];

if ($brand_filter) {
    $query .= " AND w.brand_id = ?";
    $params[] = $brand_filter;
}
if ($gender_filter) {
    $query .= " AND w.gender = ?";
    $params[] = $gender_filter;
}
if ($price_filter) {
    if ($price_filter === "low") {
        $query .= " ORDER BY w.price ASC";
    } elseif ($price_filter === "high") {
        $query .= " ORDER BY w.price DESC";
    }
}

// Prepare and execute query
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, str_repeat("s", count($params)), ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$products = mysqli_fetch_all($result, MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<?php
	include("nav.php");
	?>
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-3">Products</h2>
    <form class="mb-4" method="GET" action="">
        <div class="row g-3">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Search by Model Name" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-3">
                <select name="brand" class="form-control">
                    <option value="">Filter by Brand</option>
                    <?php foreach ($brands as $brand): ?>
                        <option value="<?php echo $brand['id']; ?>" <?php echo ($brand_filter == $brand['id']) ? 'selected' : ''; ?>><?php echo $brand['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="gender" class="form-control">
                    <option value="">Filter by Gender</option>
                    <option value="Male" <?php echo ($gender_filter == "Male") ? 'selected' : ''; ?>>Male</option>
                    <option value="Female" <?php echo ($gender_filter == "Female") ? 'selected' : ''; ?>>Female</option>
                    <option value="Unisex" <?php echo ($gender_filter == "Unisex") ? 'selected' : ''; ?>>Unisex</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="price" class="form-control">
                    <option value="">Sort by Price</option>
                    <option value="low" <?php echo ($price_filter == "low") ? 'selected' : ''; ?>>Low to High</option>
                    <option value="high" <?php echo ($price_filter == "high") ? 'selected' : ''; ?>>High to Low</option>
                </select>
            </div>
            <div class="col-md-12 text-end">
				<a href="add_product.php" class="btn btn-success ms-2">Add New Product</a>
                <button type="submit" class="btn btn-primary">Apply Filters</button>
            </div>
        </div>
    </form>

    <div class="row">
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $product): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <!-- Display image using base64 encoding -->
                        <img src="data:image/jpeg;base64,<?php echo base64_encode($product['image_url']); ?>" class="card-img-top" alt="Product Image">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $product['model_name']; ?></h5>
                            <p class="card-text">
                                Brand: <?php echo $product['brand_name']; ?><br>
                                
                                Price: $<?php echo $product['price']; ?>
                            </p>
                        </div>
                        <div class="card-footer">
                            <a href="product_details.php?id=<?php echo $product['id']; ?>" class="btn btn-primary w-100">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">No products found.</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
