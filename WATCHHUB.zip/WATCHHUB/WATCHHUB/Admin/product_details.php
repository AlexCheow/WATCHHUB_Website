<?php
include("connection.php");

// Fetch the product ID from the URL
$product_id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$product_id) {
    die("Product ID is missing.");
}

// Fetch product details
$query = "SELECT w.*, b.name AS brand_name FROM watch w JOIN brand b ON w.brand_id = b.id WHERE w.id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$product = mysqli_fetch_assoc($result);

if (!$product) {
    die("Product not found.");
}

// Handle product update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_product'])) {
    $model_name = $_POST['model_name'];
    $gender = $_POST['gender'];
    $case_material = $_POST['case_material'];
    $movement_type = $_POST['movement_type'];
    $strap_material = $_POST['strap_material'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $specification = $_POST['specification'];

    $update_query = "UPDATE watch SET model_name = ?, gender = ?, case_material = ?, movement_type = ?, strap_material = ?, price = ?, description = ?, specification = ? WHERE id = ?";
    $update_stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($update_stmt, "ssssssdsi", $model_name, $gender, $case_material, $movement_type, $strap_material, $price, $description, $specification, $product_id);

    if (mysqli_stmt_execute($update_stmt)) {
        echo "Product updated successfully.";
        header("Location: products.php");
    } else {
        echo "Error updating product.";
    }
}

// Handle status toggle
if (isset($_POST['toggle_status'])) {
    $new_status = $product['status'] == 'active' ? 'deactivate' : 'active';

    $toggle_query = "UPDATE watch SET status = ? WHERE id = ?";
    $toggle_stmt = mysqli_prepare($conn, $toggle_query);
    mysqli_stmt_bind_param($toggle_stmt, "si", $new_status, $product_id);

    if (mysqli_stmt_execute($toggle_stmt)) {
        echo "Product status updated successfully.";
        header("Location: products.php");
    } else {
        echo "Error updating product status.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include("nav.php"); ?>
</head>
<body>
<div class="container mt-4">
    <h2>Product Details</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="model_name" class="form-label">Model Name</label>
            <input type="text" name="model_name" id="model_name" class="form-control" value="<?php echo htmlspecialchars($product['model_name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="brand_name" class="form-label">Brand</label>
            <input type="text" id="brand_name" class="form-control" value="<?php echo htmlspecialchars($product['brand_name']); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="gender" class="form-label">Gender</label>
            <select name="gender" id="gender" class="form-control" required>
                <option value="Male" <?php echo ($product['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo ($product['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                <option value="Unisex" <?php echo ($product['gender'] == 'Unisex') ? 'selected' : ''; ?>>Unisex</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="case_material" class="form-label">Case Material</label>
            <input type="text" name="case_material" id="case_material" class="form-control" value="<?php echo htmlspecialchars($product['case_material']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="movement_type" class="form-label">Movement Type</label>
            <input type="text" name="movement_type" id="movement_type" class="form-control" value="<?php echo htmlspecialchars($product['movement_type']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="strap_material" class="form-label">Strap Material</label>
            <input type="text" name="strap_material" id="strap_material" class="form-control" value="<?php echo htmlspecialchars($product['strap_material']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="number" step="0.01" name="price" id="price" class="form-control" value="<?php echo htmlspecialchars($product['price']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea name="description" id="description" class="form-control" required><?php echo htmlspecialchars($product['description']); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="specification" class="form-label">Specification</label>
            <textarea name="specification" id="specification" class="form-control" required><?php echo htmlspecialchars($product['specification']); ?></textarea>
        </div>

        <div class="d-flex justify-content-between">
            <button type="submit" name="update_product" class="btn btn-success">Update Product</button>
            <button type="submit" name="toggle_status" class="btn btn-<?php echo $product['status'] == 'active' ? 'warning' : 'success'; ?>">
                <?php echo $product['status'] == 'active' ? 'Deactivate' : 'Activate'; ?> Product
            </button>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
