<?php
include("connection.php");
session_start();

// Get the search term from the query string, if any
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Fetch all customers, filtered by the search term if provided
$query = "SELECT id, firstname, lastname FROM user";
if ($search) {
    $query .= " WHERE firstname LIKE '%$search%' OR lastname LIKE '%$search%'";
}
$query .= " ORDER BY firstname";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include("nav.php"); ?>
</head>
<body>
<div class="container mt-5">
    <h2>Customers</h2>

    <!-- Search form -->
    <form class="d-flex mb-4" method="GET" action="">
        <input class="form-control me-2" type="search" name="search" placeholder="Search customers" value="<?php echo htmlspecialchars($search); ?>">
        <button class="btn btn-outline-primary" type="submit">Search</button>
    </form>

    <table class="table table-bordered table-striped mt-4">
        <thead>
            <tr>
                <th>Customer Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($customer = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($customer['firstname'] . " " . $customer['lastname']); ?></td>
                        <td>
                            <a href="customer_details.php?user_id=<?php echo $customer['id']; ?>" class="btn btn-info">View Details</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="2" class="text-center">No customers found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
