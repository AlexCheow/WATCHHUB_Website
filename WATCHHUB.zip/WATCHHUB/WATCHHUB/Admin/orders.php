<?php
include("connection.php");

// Get the selected status and search term from the GET request
$selected_status = $_GET['status'] ?? '';
$search_term = $_GET['search'] ?? '';

// Define possible statuses
$statuses = ["Order Processed", "Order Shipped", "En Route", "Order Arrived"];

// Build the query based on the selected status and search term
$order_query = "SELECT r.receipt_id, r.invoice_number, r.created_at, d.status
                FROM receipts r
                JOIN delivery_status d ON r.receipt_id = d.receipt_id
                WHERE 1";

// Apply status filter if selected
if ($selected_status && in_array($selected_status, $statuses)) {
    $order_query .= " AND d.status = '$selected_status'";
}

// Apply search filter if provided
if ($search_term) {
    $order_query .= " AND r.invoice_number LIKE '%$search_term%'";
}

$order_query .= " ORDER BY r.created_at DESC";
$orders = $conn->query($order_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Delivery Status Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<?php include("nav.php"); ?>
</head>
<body>

<div class="container my-5">
    <h2>Delivery Status Dashboard</h2>

    <!-- Filter Form with Status Dropdown and Search Bar -->
    <form method="GET" class="row g-3 my-4">
        <div class="col-md-4">
            <label for="status" class="form-label">Filter by Status:</label>
            <select name="status" id="status" class="form-select" onchange="this.form.submit()">
                <option value="">All Statuses</option>
                <?php foreach ($statuses as $status): ?>
                    <option value="<?php echo $status; ?>" <?php echo ($status === $selected_status) ? 'selected' : ''; ?>>
                        <?php echo $status; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-6">
            <label for="search" class="form-label">Search by Invoice Number:</label>
            <input type="text" name="search" id="search" class="form-control" placeholder="Enter Invoice Number" value="<?php echo htmlspecialchars($search_term); ?>">
        </div>
        <div class="col-md-2 align-self-end">
            <button type="submit" class="btn btn-primary w-100">Search</button>
        </div>
    </form>

    <!-- Orders Table -->
    <table class="table table-striped table-bordered">
        <thead class="table-light">
            <tr>
                <th>Invoice Number</th>
                <th>Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($order['invoice_number']); ?></td>
                    <td><?php echo date('d/m/Y', strtotime($order['created_at'])); ?></td>
                    <td><?php echo htmlspecialchars($order['status']); ?></td>
                    <td>
                        <a href="update_order.php?id=<?php echo $order['receipt_id']; ?>" class="btn btn-info btn-sm">View</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
