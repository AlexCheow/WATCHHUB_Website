<?php
include("connection.php");

$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$title = $_GET['title'] ?? '';

// Construct the query with filters
$product_query = "SELECT * FROM stock_control WHERE 1";

// Apply filters if provided
if ($startDate && $endDate) {
    $product_query .= " AND created_at BETWEEN '$startDate' AND '$endDate'";
}

if ($title) {
    $product_query .= " AND title LIKE '%$title%'";
}

$product_query .= " ORDER BY created_at DESC";
$result = $conn->query($product_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stock Adjustment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<?php include("nav.php"); ?>
</head>
<body>
    <div class="container my-4">
        <h1 class="mb-4">Stock Adjustment</h1>

        <!-- Filter Form -->
        <form method="GET" class="row g-3 mb-4">
            <div class="col-md-3">
                <label for="start_date" class="form-label">Start Date</label>
                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
            </div>
            <div class="col-md-3">
                <label for="end_date" class="form-label">End Date</label>
                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
            </div>
            <div class="col-md-4">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" placeholder="Enter title" value="<?php echo htmlspecialchars($title); ?>">
            </div>
            <div class="col-md-2 align-self-end">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </form>

        <button onclick="window.location.href='add_adjustment.php'" class="btn btn-success mb-3">Add New</button>

        <!-- Results Table -->
        <table class="table table-striped table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Title</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td>Inventory Adjustment</td>
                        <td><?php echo date('d/m/Y', strtotime($row['created_at'])); ?></td>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><a href="view_adjustment.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">View</a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
