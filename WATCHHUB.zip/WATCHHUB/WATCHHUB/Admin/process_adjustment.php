<?php
include("connection.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $product_ids = $_POST['product_ids']; // Array of product IDs
    $quantities = $_POST['quantities']; // Array of quantities for each product
    $descriptions = $_POST['descriptions']; // Array of descriptions for each adjustment

    try {
        // Begin transaction
        $conn->begin_transaction();

        // Insert into stock_control table
        $insert_stock_control = "INSERT INTO stock_control (title, created_at) VALUES (?, NOW())";
        $stmt = $conn->prepare($insert_stock_control);
        $stmt->bind_param("s", $title);
        $stmt->execute();

        // Get the last inserted ID for stock_control
        $stock_control_id = $conn->insert_id;
        $stmt->close();

        // Loop through each product and insert into stock_control_products
        for ($i = 0; $i < count($product_ids); $i++) {
            $product_id = $product_ids[$i];
            $quantity_adjusted = $quantities[$i];
            $description = isset($descriptions[$i]) ? $descriptions[$i] : '';

            // Fetch current quantity of the product
            $current_quantity_query = "SELECT quantity FROM watch WHERE id = ?";
            $stmt = $conn->prepare($current_quantity_query);
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $stmt->bind_result($current_quantity);
            $stmt->fetch();
            $stmt->close();

            // Check if the new quantity will be negative
            if ($current_quantity + $quantity_adjusted < 0) {
                throw new Exception("Insufficient stock for product ID $product_id. Cannot decrease quantity below zero.");
            }

            // Insert into stock_control_products
            $insert_product = "INSERT INTO stock_control_products (stock_control_id, product_id, quantity_adjusted, descriptions) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_product);
            if (!$stmt) {
                throw new Exception("Error preparing query: " . $conn->error);
            }
            $stmt->bind_param("iiis", $stock_control_id, $product_id, $quantity_adjusted, $description);
            $stmt->execute();
            $stmt->close();

            // Update the watch table quantity for the specific product ID
            $update_watch = "UPDATE watch SET quantity = quantity + ? WHERE id = ?";
            $stmt = $conn->prepare($update_watch);
            if (!$stmt) {
                throw new Exception("Error preparing query: " . $conn->error);
            }
            $stmt->bind_param("ii", $quantity_adjusted, $product_id);
            $stmt->execute();
            $stmt->close();
        }

        // Commit transaction
        $conn->commit();

        // Redirect to stock adjustment list page or a confirmation page
        header("Location: add_stock.php");
        exit();
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollback();
        echo "<div class='alert alert-danger'>An error occurred: " . $e->getMessage() . "</div>";
    }
}
?>
