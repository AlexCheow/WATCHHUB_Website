<?php
include("connection.php");

// Get the receipt_id from the URL
$receipt_id = $_GET['id'];

// Fetch the current order information
$order_query = "SELECT r.invoice_number, r.created_at, d.status
                FROM receipts r
                JOIN delivery_status d ON r.receipt_id = d.receipt_id
                WHERE r.receipt_id = $receipt_id";
$order_result = $conn->query($order_query);
$order = $order_result->fetch_assoc();

// Define possible statuses
$statuses = ["Order Processed", "Order Shipped", "En Route", "Order Arrived"];

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_status = $_POST['status'];

    // Update the status in the database
    $update_query = "UPDATE delivery_status SET status = '$new_status' WHERE receipt_id = $receipt_id";
    if ($conn->query($update_query) === TRUE) {
        // Redirect back to the admin dashboard with a success message
        header("Location: admin_delivery_status_list.php?message=Status updated successfully");
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Order Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<?php include("nav.php"); ?>
</head>
<body>

<div class="container my-5">
    <h2>Update Order Status</h2>
    <p><strong>Invoice Number:</strong> <?php echo htmlspecialchars($order['invoice_number']); ?></p>
    <p><strong>Order Date:</strong> <?php echo date('d/m/Y', strtotime($order['created_at'])); ?></p>

    <!-- Update Status Form -->
    <form method="POST">
        <div class="mb-3">
            <label for="status" class="form-label">Update Status:</label>
            <select name="status" id="status" class="form-select" required>
                <?php foreach ($statuses as $status): ?>
                    <option value="<?php echo $status; ?>" <?php echo ($status === $order['status']) ? 'selected' : ''; ?>>
                        <?php echo $status; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update Status</button>
        <a href="admin_delivery_status_list.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
